function w(t, n) {
  if (t?.version !== 1 || !Array.isArray(t.notes) || !t.notes.length || t.notes.length > 2e4)
    throw new Error("Expected a version 1 chart with 1–20,000 notes.");
  let o = -1;
  const a = Array(5).fill(-1);
  return t.notes.map((e) => {
    if (!Number.isFinite(e.time) || e.time < 0 || e.time >= n || e.time - o < 0.04)
      throw new Error(
        "Chart times must increase, be at least 40 ms apart, and fit this track."
      );
    if (!Array.isArray(e.lanes) || !e.lanes.length || e.lanes.length > 5 || new Set(e.lanes).size !== e.lanes.length || e.lanes.some((s) => !Number.isInteger(s) || s < 0 || s > 4))
      throw new Error("Each note needs unique lanes from 0 through 4.");
    if (e.duration !== void 0 && (!Number.isFinite(e.duration) || e.duration < 0 || e.time + e.duration > n))
      throw new Error("Hold duration must be nonnegative and fit this track.");
    if (e.lanes.some((s) => a[s] > e.time)) throw new Error("A fret cannot overlap its previous hold.");
    for (const s of e.lanes) a[s] = e.time + (e.duration || 0);
    return o = e.time, { time: e.time, lanes: [...e.lanes].sort(), ...e.duration > 0 ? { duration: e.duration } : {} };
  });
}
function C(t = {}) {
  const n = (o, a, e, s) => Number.isFinite(t?.[o]) && t[o] >= e && t[o] <= s ? t[o] : a;
  return { chords: t?.chords !== !1, bpm: n("bpm", 120, 40, 240), firstBeat: n("firstBeat", 2.5, 0, 120), offset: n("offset", 0, -500, 500), difficulty: ["easy", "medium", "expert"].includes(t?.difficulty) ? t.difficulty : "medium", mode: t?.mode === "strum" ? "strum" : "tap" };
}
const $ = (t) => {
  if (!/^[\w-]{11}$/.test(t)) throw new Error("Invalid recording ID.");
  return `vh.chart.${t}`;
};
async function E(t, n, o, a, e, s) {
  const r = $(n);
  if (!Number.isFinite(a) || a < 3 || a > 1200) throw new Error("The song duration is unavailable. Try saving after the song loads.");
  const i = { version: 1, youtubeId: n, notes: w(o, a), duration: a, settings: C(e), title: String(s || "").slice(0, 300), savedAt: (/* @__PURE__ */ new Date()).toISOString() };
  if (JSON.stringify(i).length > 2 * 1024 * 1024) throw new Error("This chart is too large to save.");
  return await t.set({ [r]: i }), i;
}
function S(t) {
  if (t?.version !== 1 || !Array.isArray(t.charts) || !t.charts.length || t.charts.length > 200) throw new Error("Choose a Vibe Hero song pack with 1–200 charts.");
  const n = /* @__PURE__ */ new Set();
  return t.charts.map((o) => {
    if (!/^[\w-]{11}$/.test(o.youtubeId || "") || n.has(o.youtubeId) || !Number.isFinite(o.duration) || o.duration < 3 || o.duration > 1200) throw new Error("Song pack contains an invalid or duplicate recording.");
    return n.add(o.youtubeId), { ...o, notes: w(o, o.duration) };
  });
}
async function k(t, n) {
  const o = S(t), a = [];
  for (const e of o)
    try {
      await E(n, e.youtubeId, e, e.duration, e.settings, e.title), a.push(e.youtubeId);
    } catch (s) {
      throw new Error(`Imported ${a.length} of ${o.length} songs. ${s.message} You can retry this pack.`);
    }
  return a.length;
}
const p = document.querySelector("#status"), b = document.querySelector("#progress"), v = document.querySelector("#cancel"), f = document.querySelector("#songs");
let y = !1;
async function g() {
  if (!y) {
    y = !0;
    try {
      const t = await chrome.storage.local.get(null), n = t["vh.preparation"], o = n?.status === "preparing" && Date.now() - n.updatedAt > 15e3;
      p.textContent = n ? `${n.title || n.videoId} — ${o ? "No recent progress. The song may be paused, playing an ad, or preparation may have stopped. Check its tab." : n.status === "ready" ? "Saved and ready to play." : n.status === "preparing" ? `Preparing quietly · ${n.progress}%` : n.error || n.status}` : "Nothing preparing.", b.hidden = n?.status !== "preparing", b.value = n?.progress || 0, v.hidden = n?.status !== "preparing";
      const a = document.querySelector("#scores");
      a.replaceChildren();
      const e = Object.entries(t).filter(([r]) => r.startsWith("vh.score.")).map(([, r]) => r).sort((r, i) => String(i.date).localeCompare(String(r.date)));
      e.length || (a.textContent = "Finish a set and save your score with a player name.");
      for (const r of e) {
        const i = document.createElement("article"), u = document.createElement("strong"), h = document.createElement("p");
        u.textContent = `${r.username} · ${Number(r.score).toLocaleString()} points · ${r.title}`, h.textContent = `${r.outcome === "failed" ? "Failed attempt · " : r.competitiveEligible === !1 ? "Practice · " : ""}${r.difficulty} · ${r.chords ? "chords on" : "single notes"} · ${r.accuracy}% · best streak ${r.best} · ${new Date(r.date).toLocaleString()}`;
        const c = document.createElement("button");
        c.textContent = "Export score", c.onclick = () => {
          const l = URL.createObjectURL(new Blob([JSON.stringify(r)], { type: "application/json" })), d = document.createElement("a");
          d.href = l, d.download = `vibe-hero-score-${r.id}.json`, d.click(), setTimeout(() => URL.revokeObjectURL(l), 1e3);
        }, i.append(u, h, c), a.append(i);
      }
      f.replaceChildren();
      const s = Object.entries(t).filter(([r, i]) => r.startsWith("vh.chart.") && /^[\w-]{11}$/.test(i?.youtubeId || "") && Array.isArray(i.notes)).map(([, r]) => r).sort((r, i) => String(i.savedAt).localeCompare(String(r.savedAt)));
      s.length || (f.textContent = "Your saved charts will appear here. Previous JSON downloads can be imported through the game and saved to this library.");
      for (const r of s) {
        const i = document.createElement("article"), u = document.createElement("h3"), h = document.createElement("small"), c = document.createElement("a"), l = document.createElement("button");
        u.textContent = r.title || r.youtubeId, h.textContent = `${r.notes.length} notes · ${r.settings?.difficulty || "custom"} · ${r.settings?.bpm || "?"} BPM · saved ${new Date(r.savedAt).toLocaleString()}`, c.textContent = "Open on YouTube ↗", c.href = `https://www.youtube.com/watch?v=${r.youtubeId}`, c.target = "_blank", c.rel = "noopener", l.textContent = "Download backup", l.className = "secondary", l.onclick = () => {
          const d = URL.createObjectURL(new Blob([JSON.stringify(r)], { type: "application/json" })), m = document.createElement("a");
          m.href = d, m.download = `vibe-hero-${r.youtubeId}.json`, document.body.append(m), m.click(), m.remove(), setTimeout(() => URL.revokeObjectURL(d), 1e3);
        }, i.append(u, h, c, l), f.append(i);
      }
    } catch (t) {
      p.textContent = `Could not load library: ${t.message}`;
    } finally {
      y = !1;
    }
  }
}
v.onclick = async () => {
  try {
    const t = await chrome.runtime.sendMessage({ target: "background", type: "cancel" });
    if (t?.error) throw new Error(t.error);
    p.textContent = "Cancellation requested…";
  } catch (t) {
    p.textContent = t.message;
  }
};
chrome.storage.onChanged.addListener(g);
g();
setInterval(g, 5e3);
document.querySelector("#import-pack").onchange = async (t) => {
  const n = t.target, o = n.files?.[0], a = document.querySelector("#import-status");
  if (o) {
    n.disabled = !0;
    try {
      if (o.size > 30 * 1024 * 1024) throw new Error("Choose a song pack smaller than 30 MB.");
      a.textContent = "Importing prepared songs…";
      const e = await k(JSON.parse(await o.text()), chrome.storage.local);
      a.textContent = `${e} songs saved and ready to play. Open any song and click the extension Play button.`, await g();
    } catch (e) {
      a.textContent = `Could not finish import: ${e.message}`;
    } finally {
      n.disabled = !1, n.value = "";
    }
  }
};
