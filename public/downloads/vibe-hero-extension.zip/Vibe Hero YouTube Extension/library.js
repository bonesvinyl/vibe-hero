function G(e, n) {
  if (e?.version !== 1 || !Array.isArray(e.notes) || !e.notes.length || e.notes.length > 2e4)
    throw new Error("Expected a version 1 chart with 1–20,000 notes.");
  let s = -1;
  const o = Array(5).fill(-1);
  return e.notes.map((a) => {
    if (!Number.isFinite(a.time) || a.time < 0 || a.time >= n || a.time - s < 0.04)
      throw new Error(
        "Chart times must increase, be at least 40 ms apart, and fit this track."
      );
    if (!Array.isArray(a.lanes) || !a.lanes.length || a.lanes.length > 5 || new Set(a.lanes).size !== a.lanes.length || a.lanes.some((c) => !Number.isInteger(c) || c < 0 || c > 4))
      throw new Error("Each note needs unique lanes from 0 through 4.");
    if (a.duration !== void 0 && (!Number.isFinite(a.duration) || a.duration < 0 || a.time + a.duration > n))
      throw new Error("Hold duration must be nonnegative and fit this track.");
    if (a.lanes.some((c) => o[c] > a.time)) throw new Error("A fret cannot overlap its previous hold.");
    for (const c of a.lanes) o[c] = a.time + (a.duration || 0);
    return s = a.time, { time: a.time, lanes: [...a.lanes].sort(), ...a.duration > 0 ? { duration: a.duration } : {} };
  });
}
function _(e = {}) {
  const n = (s, o, a, c) => Number.isFinite(e?.[s]) && e[s] >= a && e[s] <= c ? e[s] : o;
  return { chords: e?.chords !== !1, bpm: n("bpm", 120, 40, 240), firstBeat: n("firstBeat", 2.5, 0, 120), offset: n("offset", 0, -500, 500), difficulty: ["easy", "medium", "expert"].includes(e?.difficulty) ? e.difficulty : "medium", mode: e?.mode === "strum" ? "strum" : "tap" };
}
const ee = (e) => {
  if (!/^[\w-]{11}$/.test(e)) throw new Error("Invalid recording ID.");
  return `vh.chart.${e}`;
};
async function te(e, n, s, o, a, c) {
  const i = ee(n);
  if (!Number.isFinite(o) || o < 3 || o > 1200) throw new Error("The song duration is unavailable. Try saving after the song loads.");
  const r = { version: 1, youtubeId: n, notes: G(s, o), duration: o, settings: _(a), title: String(c || "").slice(0, 300), savedAt: (/* @__PURE__ */ new Date()).toISOString() };
  if (JSON.stringify(r).length > 2 * 1024 * 1024) throw new Error("This chart is too large to save.");
  return await e.set({ [i]: r }), r;
}
function Z(e) {
  if (e?.version !== 1 || !Array.isArray(e.charts) || !e.charts.length || e.charts.length > 200) throw new Error("Choose a Vibe Hero song pack with 1–200 charts.");
  const n = /* @__PURE__ */ new Set();
  return e.charts.map((s) => {
    if (!/^[\w-]{11}$/.test(s.youtubeId || "") || n.has(s.youtubeId) || !Number.isFinite(s.duration) || s.duration < 3 || s.duration > 1200) throw new Error("Song pack contains an invalid or duplicate recording.");
    return n.add(s.youtubeId), { ...s, notes: G(s, s.duration) };
  });
}
async function ne(e, n) {
  const s = Z(e), o = [];
  for (const a of s)
    try {
      await te(n, a.youtubeId, a, a.duration, a.settings, a.title), o.push(a.youtubeId);
    } catch (c) {
      throw new Error(`Imported ${o.length} of ${s.length} songs. ${c.message} You can retry this pack.`);
    }
  return o.length;
}
const R = [{ id: "indie", name: "Indie Afterparty", genre: "Indie rock", kind: "pack", songIds: ["ltYq-jalYm0", "oIIxlgcuQRU", "iWOyfLBYtuU", "NUnXxh5U25Y", "hN5X4kGhAtU", "9AEoUa0Hlso", "a0ul-BghOAs", "CTAud5O7Qqk", "zYwCmcB0XMw", "ZoK63Bk7pgw", "Gb31AKjmKos", "OC5zHACynR4", "auzfTPp4moA", "tti76BnCL98", "oUknlSWNbEI", "j-fWDrZSiZs", "veHqJSC-9Lo", "xZl-ssLKyPE", "Oextk-If8HQ", "eimgRedLkkU", "28tZ-S1LFok", "UrMmr1oMPGA", "ewRjZoRtu0Y", "fe4EK4HSPkI", "P8a4iiOnzsc", "PQZhN65vq9E", "gGdGFtwCNBE", "Kk8eJh4i8Lo", "Pib8eYDSFEI", "Zx4Hjq6KwO0", "2EIeUlvHAiM", "SDTZ7iX4vTQ", "B9dSYgd5Elk", "6EWImmZfgtc", "s2YiUTh9dj4", "jxKjOOR9sPU", "q-SJjFcnsGs", "5bfseWNmlds", "aaMD2N-Jy8Y", "YXwYJyrKK5A", "UYIAfiVGluk", "DWD7CNFlsOc", "U_OKigBRqBI", "ma9I9VBKPiw", "GhCXAiNz9Jo", "5yBBaK1vGh4", "MmZexg8sxyk", "5tZlu4wP4pw", "GoLJJRIWCLU"] }, { id: "yacht", name: "Yacht Rock", genre: "Yacht rock", kind: "pack", songIds: ["o1BqHjNafRk", "u_pt3khMRFs", "CFhFyvk0yS8", "FXG_I_tf_i4", "7xvvLT_jRZY", "DzXEos0xIQM", "ohDqjRGqpIU", "QAo_Ycocl1E", "BVXmy22EoLA", "6POZlJAZsok", "IHL-6cUtZj0", "32Oc2d_3yEk", "WOBHXxiZyZM", "Yxy1eF_w7sU", "cvg5mbM6FGs", "SdfW_2frXnE", "3bRN257PBIg", "exiyXAV-aVQ", "swJOIjjW69U", "ywL6tMQdG4c", "5fYUpVAb34I", "EI0Tt3UZ5jc", "6mj-p6rITBw", "Omnpu8mzX4c", "EIMk9F7E0uM", "9QYk1E8zdxU", "gtlqZOT2fOo", "NoPH9LvVkDU", "1j_YC8OpSr4", "ky6vvIESPiM", "Ueivjr3f8xg", "Rq-7NgH-hcs", "OaOQdWyN67U", "XOuFO8KPnjw", "nCEuT91UAcg", "jEILGYq7eso", "Fa25MqOzGwk", "IL_LiGCV82g", "r8xZSwHirLg", "pFCi5usCbz4", "QCgeitX5xg0", "WH5WVmaZFNE", "Ot3JJ0wv2G0", "QQD-OvbCfCU", "8vpgoNDi71Q", "pCRoAKdKPVA", "oFXIHZ2mzIU", "v4XKRHyu3C8", "k1uA_Zw7zAk", "op9ApJJyhD4", "S3ta4T9tIUM", "TGkUdLJCLyE", "wzCdSJu5xqI", "tNtOYomo4Qg", "lHLr5dT4XHc", "3e8xSISlPJs", "XKc7z-enzmA", "6tynWSAesAo", "9KNuZrEVB70", "Kj4-_-iq1A8", "M-Z3BAW7o3c", "xftwDQ2PhvA", "kR5Ki6jjPaY", "GRQl9k71EBg", "Gby-B2xsuuQ", "muQqts3-g1w", "Yoithw8ysjo", "L0qBulm0hbg", "uu3QahP4uig", "0qycxTpMb5U", "qrU1Zg0wugE", "k5gOehkLUTk", "0VplLt39yrk", "McZYYe0kAtg", "O6abLniPBFU", "iM5Rd6oM-C4", "nuko5fhd4mA", "lnc2ljZA3bk", "yi4hbVAfRCw", "MG0e8_foDmU", "m0tmkm9KIAo", "1AVxBedMP4I", "ySy1y10JIpM", "ciLNMesqPh0", "7Ki7f4g9X9g", "lPkEpfwJX_Q", "irl89Gmcv8c", "XFnkJGoaDUs", "f1De87ETXwo", "n2orykBfo5o", "EZ-nCesR-oY", "zxFxl5NjBzc", "8cqhZ47Hg7g", "D4ZrKfrshP4"] }], Y = "vh.song.", N = "vh.setlist.";
function q(e) {
  return String(e || "").replace(/^\(\d+\)\s*/, "").replace(/\s*[[(](?:official\s+)?(?:music\s+)?(?:video|audio|lyrics?|visuali[sz]er)(?:\s+(?:hd|4k))?[\])]/gi, "").replace(/\s*[-–]\s*official\s+(?:music\s+)?(?:video|audio)\s*$/i, "").trim();
}
function K(e) {
  const n = Object.entries(e).filter(([i, r]) => i.startsWith("vh.chart.") && /^[\w-]{11}$/.test(r?.youtubeId || "") && Array.isArray(r.notes)).map(([, i]) => i), s = Object.entries(e).filter(([i, r]) => i.startsWith("vh.score.") && r?.videoId).map(([, i]) => i), o = Object.entries(e).filter(([i, r]) => i.startsWith(N) && r?.id && Array.isArray(r.songIds)).map(([, i]) => i), a = [...R.filter((i) => n.some((r) => i.songIds.includes(r.youtubeId))).map((i) => ({ ...i, ...e[N + i.id] })), ...o.filter((i) => !R.some((r) => r.id === i.id))], c = n.map((i) => {
    const r = i.youtubeId, d = e[Y + r] || {}, l = a.filter((g) => g.kind === "pack" && g.songIds.includes(r));
    return {
      id: r,
      chart: i,
      title: d.title || q(i.title) || r,
      genre: d.genre ?? l[0]?.genre ?? a.find((g) => g.songIds.includes(r) && g.genre)?.genre ?? "",
      packs: l,
      scores: s.filter((g) => g.videoId === r).sort((g, h) => String(h.date).localeCompare(String(g.date)))
    };
  });
  for (const i of s) if (!c.some((r) => r.id === i.videoId)) {
    const r = i.videoId, d = e[Y + r] || {};
    c.push({ id: r, chart: null, title: d.title || q(i.title) || r, genre: d.genre || "", packs: [], scores: s.filter((l) => l.videoId === r).sort((l, g) => String(g.date).localeCompare(String(l.date))) });
  }
  return { songs: c, sets: a };
}
function X(e, n, { collection: s = "all", query: o = "", genre: a = "", sort: c = "recent" } = {}) {
  const i = n.find((l) => l.id === s), r = o.toLowerCase().trim();
  return e.filter((l) => (s === "all" || s === "manual" && !l.packs.length || i?.songIds.includes(l.id)) && (!a || l.genre === a) && (!r || `${l.title} ${l.genre} ${l.id}`.toLowerCase().includes(r))).sort((l, g) => c === "title" ? l.title.localeCompare(g.title) : c === "genre" ? l.genre.localeCompare(g.genre) || l.title.localeCompare(g.title) : c === "order" && i ? i.songIds.indexOf(l.id) - i.songIds.indexOf(g.id) : String(g.chart?.savedAt || "").localeCompare(String(l.chart?.savedAt || "")));
}
function T(e, n) {
  return { ...e, songIds: [.../* @__PURE__ */ new Set([...e.songIds, ...n])] };
}
function j(e, n, s) {
  const o = e.songIds.filter((c) => c !== n), a = o.indexOf(s);
  return o.splice(a < 0 ? o.length : a, 0, n), { ...e, songIds: o };
}
const H = (e) => e ? JSON.stringify([e.videoId, e.status, e.updatedAt, e.title, e.error]) : "", t = (e) => document.getElementById(e), v = chrome.storage.local;
let B = {}, p = { songs: [], sets: [] }, S = "all", k = 0, m = /* @__PURE__ */ new Set(), $ = null, E = [], A = null, C = null, P = !1, J = 0;
const O = 20;
function u(e, n, s) {
  const o = document.createElement(e);
  return n !== void 0 && (o.textContent = n), s && (o.className = s), o;
}
function M(e, n) {
  const s = u("button", e);
  return s.type = "button", s.onclick = () => b(n), s;
}
function y(e) {
  t("message").textContent = e;
}
async function b(e) {
  try {
    await e();
  } catch (n) {
    y(`Could not save changes: ${n.message}`);
  }
}
function F(e, n) {
  const s = URL.createObjectURL(new Blob([JSON.stringify(e)], { type: "application/json" })), o = u("a");
  o.href = s, o.download = n, document.body.append(o), o.click(), o.remove(), setTimeout(() => URL.revokeObjectURL(s), 1e3);
}
function D() {
  return p.sets.find((e) => e.id === S);
}
async function x(e) {
  await v.set({ [N + e.id]: e }), await U();
}
async function U() {
  if (P) return;
  const e = ++J;
  try {
    const n = await v.get(null);
    if (e !== J) return;
    B = n, p = K(B), I();
  } catch (n) {
    y(`Could not load your library: ${n.message}`);
  }
}
function Q(e) {
  S = e, k = 0, m.clear(), I();
}
function I() {
  const e = t("collections");
  e.replaceChildren();
  function n(r, d, l, g) {
    const h = M("", () => Q(r));
    h.append(u("span", d), u("small", String(l))), h.setAttribute("aria-current", r === S ? "page" : "false"), g && (h.ondragover = (f) => {
      f.preventDefault(), h.classList.add("drop-target");
    }, h.ondragleave = () => h.classList.remove("drop-target"), h.ondrop = (f) => {
      f.preventDefault(), h.classList.remove("drop-target");
      const w = f.dataTransfer.getData("text/plain");
      p.songs.some((L) => L.id === w) && b(async () => {
        await x(T(g, [w])), y(`Added song to ${g.name}.`);
      });
    }), e.append(h);
  }
  n("all", "All songs", p.songs.length), n("manual", "Manual additions", p.songs.filter((r) => !r.packs.length).length);
  for (const r of ["pack", "custom"]) {
    e.append(u("h2", r === "pack" ? "Song packs" : "Your setlists"));
    for (const d of p.sets.filter((l) => (l.kind === "pack" ? "pack" : "custom") === r)) n(d.id, d.name, p.songs.filter((l) => d.songIds.includes(l.id)).length, d);
  }
  const s = [...new Set(p.songs.map((r) => r.genre).filter(Boolean))].sort(), o = t("genre").value;
  t("genre").replaceChildren(new Option("All genres", ""), ...s.map((r) => new Option(r, r))), t("genre").value = s.includes(o) ? o : "", t("genres").replaceChildren(...s.map((r) => new Option(r, r)));
  const a = t("target-set").value;
  t("target-set").replaceChildren(new Option("Choose a setlist", ""), ...p.sets.map((r) => new Option(r.name, r.id))), t("target-set").value = a;
  const c = D();
  t("collection-title").textContent = c?.name || (S === "manual" ? "Manual additions" : "All songs"), t("rename-set").hidden = !c, t("remove-selected").hidden = !c;
  const i = X(p.songs, p.sets, { collection: S, query: t("search").value, genre: t("genre").value, sort: t("sort").value });
  k = Math.max(0, Math.min(k, Math.ceil(i.length / O) - 1)), E = i.slice(k * O, (k + 1) * O), t("count").textContent = `${i.length} songs${c?.genre ? " · " + c.genre : ""}`, t("songs").replaceChildren(), E.length || t("songs").append(u("p", p.songs.length ? "No songs match. Try another collection or clear your filters." : "Import your first song pack, or prepare a song from the extension popup.", "empty"));
  for (const r of E) {
    const d = u("article", void 0, "song-row");
    d.draggable = !0, d.ondragstart = (f) => f.dataTransfer.setData("text/plain", r.id), d.ondragover = (f) => {
      c && t("sort").value === "order" && (f.preventDefault(), d.classList.add("drop-target"));
    }, d.ondragleave = () => d.classList.remove("drop-target"), d.ondrop = (f) => {
      f.preventDefault(), d.classList.remove("drop-target");
      const w = f.dataTransfer.getData("text/plain");
      c && t("sort").value === "order" && c.songIds.includes(w) && w !== r.id && b(() => x(j(c, w, r.id)));
    };
    const l = u("input");
    l.type = "checkbox", l.checked = m.has(r.id), l.setAttribute("aria-label", `Select ${r.title}`), l.onchange = () => {
      l.checked ? m.add(r.id) : m.delete(r.id), z();
    };
    const g = M("", () => V(r.id));
    g.className = "song-info", g.append(u("strong", r.title), u("small", `${r.genre || "No genre"} · ${r.chart ? Math.round(r.chart.settings?.bpm || 120) + " BPM" : "Chart not installed"} · ${r.scores.length} saved scores`));
    const h = u("a", "Play ↗", "play-link");
    if (h.href = `https://www.youtube.com/watch?v=${r.id}`, h.target = "_blank", h.rel = "noreferrer", h.setAttribute("aria-label", `Open ${r.title} on YouTube`), d.append(l, g, h), c && t("sort").value === "order") {
      const f = c.songIds.indexOf(r.id), w = M("↑", () => x(j(c, r.id, c.songIds[f - 1])));
      w.disabled = f <= 0, w.setAttribute("aria-label", `Move ${r.title} up`);
      const L = M("↓", () => x(j(c, r.id, c.songIds[f + 2])));
      L.disabled = f >= c.songIds.length - 1, L.setAttribute("aria-label", `Move ${r.title} down`), d.append(w, L);
    }
    t("songs").append(d);
  }
  t("page-label").textContent = i.length ? `${k * O + 1}–${Math.min((k + 1) * O, i.length)} of ${i.length}` : "0 songs", t("previous").disabled = k === 0, t("next").disabled = (k + 1) * O >= i.length, z(), W();
}
function z() {
  t("selected-count").textContent = `${m.size} selected`, t("select-page").checked = E.length > 0 && E.every((e) => m.has(e.id)), t("select-page").indeterminate = E.some((e) => m.has(e.id)) && !t("select-page").checked;
  for (const e of ["add-selected", "remove-selected", "clear-selected"]) t(e).disabled = !m.size;
}
function W() {
  const e = B["vh.preparation"];
  if (t("preparation").hidden = !e || B["vh.dismissedPreparation"] === H(e), !e) return;
  const n = e.status === "preparing", s = n && Date.now() - e.updatedAt > 15e3;
  t("status").textContent = `${e.title || e.videoId}: ${s ? "No recent progress. Check the song tab or cancel preparation." : e.status === "ready" ? "Saved and ready to play." : n ? `Preparing quietly · ${Math.round(e.progress || 0)}%` : e.error || e.status}`, t("progress").hidden = !n, t("progress").value = e.progress || 0, t("cancel").hidden = !n, t("dismiss").hidden = n;
}
function V(e) {
  $ = e;
  const n = p.songs.find((s) => s.id === e);
  if (n) {
    t("song-panel").hidden = !1, t("detail-title").textContent = n.title, t("edit-title").value = n.title, t("edit-genre").value = n.genre, t("detail-play").href = `https://www.youtube.com/watch?v=${e}`, t("backup-song").disabled = !n.chart, t("memberships").replaceChildren();
    for (const s of p.sets) {
      const o = u("label", void 0, "membership"), a = u("input");
      a.type = "checkbox", a.checked = s.songIds.includes(e), a.onchange = () => b(async () => {
        const c = K(await v.get(null)).sets.find((i) => i.id === s.id);
        await x(a.checked ? T(c, [e]) : { ...c, songIds: c.songIds.filter((i) => i !== e) });
      }), o.append(a, document.createTextNode(s.name)), t("memberships").append(o);
    }
    t("song-scores").replaceChildren(), n.scores.length || t("song-scores").append(u("p", "No saved scores yet. Finish a run and save your result.", "hint"));
    for (const s of n.scores) {
      const o = u("article", void 0, "score-entry");
      o.append(u("strong", `${s.username || "Player"} · ${Number(s.score || 0).toLocaleString()} pts`), u("p", `${s.difficulty} · ${s.chords ? "Chords" : "Single notes"} · ${s.accuracy}% hit · Best streak ${s.best}`), u("small", `${s.outcome === "failed" ? "Failed attempt · " : s.competitiveEligible === !1 ? "Practice · " : ""}${new Date(s.date).toLocaleString()}`), M("Export score", () => F(s, `vibe-hero-score-${s.id}.json`))), t("song-scores").append(o);
    }
  }
}
t("close-panel").onclick = () => {
  t("song-panel").hidden = !0, $ = null;
};
t("edit-song").onsubmit = (e) => {
  e.preventDefault(), b(async () => {
    const n = t("edit-title").value.trim();
    if (!n) throw Error("Enter a song title.");
    const s = Y + $, o = (await v.get(s))[s] || {};
    await v.set({ [s]: { ...o, title: n, genre: t("edit-genre").value.trim() } }), await U(), V($), y("Song details saved.");
  });
};
t("backup-song").onclick = () => {
  const e = p.songs.find((n) => n.id === $);
  e?.chart && F({ ...e.chart, title: e.title }, `vibe-hero-${$}.json`);
};
t("new-set").onsubmit = (e) => {
  e.preventDefault(), b(async () => {
    const n = t("set-name").value.trim();
    if (!n) return;
    const s = { id: crypto.randomUUID(), name: n, kind: "custom", genre: "", songIds: [] };
    await x(s), t("set-name").value = "", Q(s.id), y("Setlist created. Drag songs here or use Add to setlist.");
  });
};
t("search").oninput = () => {
  k = 0, I();
};
t("genre").onchange = t("sort").onchange = () => {
  k = 0, I();
};
t("previous").onclick = () => {
  k--, I();
};
t("next").onclick = () => {
  k++, I();
};
t("select-page").onchange = (e) => {
  for (const n of E) e.target.checked ? m.add(n.id) : m.delete(n.id);
  I();
};
t("clear-selected").onclick = () => {
  m.clear(), I();
};
t("add-selected").onclick = () => b(async () => {
  const e = p.sets.find((n) => n.id === t("target-set").value);
  if (!e) throw Error("Choose a destination setlist.");
  await x(T(e, [...m])), y(`Added ${m.size} songs to ${e.name}.`);
});
t("remove-selected").onclick = () => b(async () => {
  const e = D();
  e && (await x({ ...e, songIds: e.songIds.filter((n) => !m.has(n)) }), m.clear(), I(), y("Removed from this setlist. Songs and scores remain in All songs."));
});
t("export-set").onclick = () => {
  const e = D(), n = X(p.songs, p.sets, { collection: S, sort: "order" }), s = n.filter((o) => o.chart).map((o) => ({ ...o.chart, title: o.title, genre: o.genre }));
  if (!s.length) {
    y("This collection has no installed charts to export.");
    return;
  }
  F({ version: 1, name: e?.name || t("collection-title").textContent, genre: e?.genre || "", charts: s }, "vibe-hero-setlist.json");
};
t("cancel").onclick = () => b(async () => {
  const e = await chrome.runtime.sendMessage({ target: "background", type: "cancel" });
  if (e?.error) throw Error(e.error);
  y("Cancellation requested.");
});
t("dismiss").onclick = () => b(async () => {
  const e = (await v.get("vh.preparation"))["vh.preparation"];
  if (e?.status === "preparing") throw Error("Preparation is active. Cancel it before dismissing.");
  await v.set({ "vh.dismissedPreparation": H(e) }), await U();
});
t("import-pack").onchange = async (e) => {
  const n = e.target.files?.[0];
  if (e.target.value = "", !!n)
    try {
      if (n.size > 30 * 1024 * 1024) throw Error("Choose a pack smaller than 30 MB.");
      A = JSON.parse(await n.text());
      const s = Z(A);
      C = null, t("pack-heading").textContent = "Import a song pack", t("pack-description").textContent = `${s.length} charts. Existing charts for the same recordings will be replaced; your titles, setlists and scores are preserved.`, t("pack-name").value = A.name || n.name.replace(/\.json$/i, "").replace(/^Vibe Hero\s*[-–]?\s*/i, ""), t("pack-genre").value = A.genre || (/yacht/i.test(n.name) ? "Yacht rock" : /indie/i.test(n.name) ? "Indie rock" : ""), t("save-pack").textContent = "Import pack", t("pack-error").textContent = "", t("pack-dialog").showModal();
    } catch (s) {
      y(s.message);
    }
};
t("rename-set").onclick = () => {
  C = D(), A = null, t("pack-heading").textContent = "Edit setlist", t("pack-description").textContent = "The genre applies to songs without their own genre override.", t("pack-name").value = C.name, t("pack-genre").value = C.genre || "", t("save-pack").textContent = "Save setlist", t("pack-error").textContent = "", t("pack-dialog").showModal();
};
t("cancel-pack").onclick = () => t("pack-dialog").close();
t("pack-form").onsubmit = async (e) => {
  e.preventDefault();
  const n = t("pack-name").value.trim(), s = t("pack-genre").value.trim();
  if (n) {
    P = !0, t("save-pack").disabled = !0, t("cancel-pack").disabled = !0;
    try {
      if (C) await v.set({ [N + C.id]: { ...C, name: n, genre: s } });
      else {
        const o = Z(A);
        await ne(A, v);
        const a = o.map((r) => r.youtubeId), i = p.sets.find((r) => r.kind === "pack" && r.songIds.length === a.length && a.every((d) => r.songIds.includes(d)))?.id || crypto.randomUUID();
        await v.set({ [N + i]: { id: i, name: n, genre: s, kind: "pack", songIds: a } }), S = i, k = 0;
      }
      t("pack-dialog").close(), y(C ? "Setlist updated." : "Song pack imported into your library.");
    } catch (o) {
      t("pack-error").textContent = o.message;
    } finally {
      P = !1, t("save-pack").disabled = !1, t("cancel-pack").disabled = !1, await U();
    }
  }
};
t("pack-dialog").addEventListener("cancel", (e) => {
  P && e.preventDefault();
});
chrome.storage.onChanged.addListener(() => U());
U();
setInterval(() => {
  P || W();
}, 5e3);
