function X(e, n) {
  if (e?.version !== 1 || !Array.isArray(e.notes) || !e.notes.length || e.notes.length > 2e4)
    throw new Error("Expected a version 1 chart with 1–20,000 notes.");
  let r = -1;
  const a = Array(5).fill(-1);
  return e.notes.map((o) => {
    if (!Number.isFinite(o.time) || o.time < 0 || o.time >= n || o.time - r < 0.04)
      throw new Error(
        "Chart times must increase, be at least 40 ms apart, and fit this track."
      );
    if (!Array.isArray(o.lanes) || !o.lanes.length || o.lanes.length > 5 || new Set(o.lanes).size !== o.lanes.length || o.lanes.some((c) => !Number.isInteger(c) || c < 0 || c > 4))
      throw new Error("Each note needs unique lanes from 0 through 4.");
    if (o.duration !== void 0 && (!Number.isFinite(o.duration) || o.duration < 0 || o.time + o.duration > n))
      throw new Error("Hold duration must be nonnegative and fit this track.");
    if (o.lanes.some((c) => a[c] > o.time)) throw new Error("A fret cannot overlap its previous hold.");
    for (const c of o.lanes) a[c] = o.time + (o.duration || 0);
    return r = o.time, { time: o.time, lanes: [...o.lanes].sort(), ...o.duration > 0 ? { duration: o.duration } : {} };
  });
}
function ee(e = {}) {
  const n = (r, a, o, c) => Number.isFinite(e?.[r]) && e[r] >= o && e[r] <= c ? e[r] : a;
  return { chords: e?.chords !== !1, bpm: n("bpm", 120, 40, 240), firstBeat: n("firstBeat", 2.5, 0, 120), offset: n("offset", 0, -500, 500), difficulty: ["easy", "medium", "expert"].includes(e?.difficulty) ? e.difficulty : "medium", mode: e?.mode === "strum" ? "strum" : "tap" };
}
const te = (e) => {
  if (!/^[\w-]{11}$/.test(e)) throw new Error("Invalid recording ID.");
  return `vh.chart.${e}`;
};
async function ne(e, n, r, a, o, c) {
  const i = te(n);
  if (!Number.isFinite(a) || a < 3 || a > 1200) throw new Error("The song duration is unavailable. Try saving after the song loads.");
  const s = { version: 1, youtubeId: n, notes: X(r, a), duration: a, settings: ee(o), title: String(c || "").slice(0, 300), savedAt: (/* @__PURE__ */ new Date()).toISOString() };
  if (JSON.stringify(s).length > 2 * 1024 * 1024) throw new Error("This chart is too large to save.");
  return await e.set({ [i]: s }), s;
}
function Z(e) {
  if (e?.version !== 1 || !Array.isArray(e.charts) || !e.charts.length || e.charts.length > 200) throw new Error("Choose a Vibe Hero song pack with 1–200 charts.");
  const n = /* @__PURE__ */ new Set();
  return e.charts.map((r) => {
    if (!/^[\w-]{11}$/.test(r.youtubeId || "") || n.has(r.youtubeId) || !Number.isFinite(r.duration) || r.duration < 3 || r.duration > 1200) throw new Error("Song pack contains an invalid or duplicate recording.");
    return n.add(r.youtubeId), { ...r, notes: X(r, r.duration) };
  });
}
async function se(e, n) {
  const r = Z(e), a = [];
  for (const o of r)
    try {
      await ne(n, o.youtubeId, o, o.duration, o.settings, o.title), a.push(o.youtubeId);
    } catch (c) {
      throw new Error(`Imported ${a.length} of ${r.length} songs. ${c.message} You can retry this pack.`);
    }
  return a.length;
}
const J = [{ id: "indie", name: "Indie Afterparty", genre: "Indie rock", kind: "pack", songIds: ["ltYq-jalYm0", "oIIxlgcuQRU", "iWOyfLBYtuU", "NUnXxh5U25Y", "hN5X4kGhAtU", "9AEoUa0Hlso", "a0ul-BghOAs", "CTAud5O7Qqk", "zYwCmcB0XMw", "ZoK63Bk7pgw", "Gb31AKjmKos", "OC5zHACynR4", "auzfTPp4moA", "tti76BnCL98", "oUknlSWNbEI", "j-fWDrZSiZs", "veHqJSC-9Lo", "xZl-ssLKyPE", "Oextk-If8HQ", "eimgRedLkkU", "28tZ-S1LFok", "UrMmr1oMPGA", "ewRjZoRtu0Y", "fe4EK4HSPkI", "P8a4iiOnzsc", "PQZhN65vq9E", "gGdGFtwCNBE", "Kk8eJh4i8Lo", "Pib8eYDSFEI", "Zx4Hjq6KwO0", "2EIeUlvHAiM", "SDTZ7iX4vTQ", "B9dSYgd5Elk", "6EWImmZfgtc", "s2YiUTh9dj4", "jxKjOOR9sPU", "q-SJjFcnsGs", "5bfseWNmlds", "aaMD2N-Jy8Y", "YXwYJyrKK5A", "UYIAfiVGluk", "DWD7CNFlsOc", "U_OKigBRqBI", "ma9I9VBKPiw", "GhCXAiNz9Jo", "5yBBaK1vGh4", "MmZexg8sxyk", "5tZlu4wP4pw", "GoLJJRIWCLU"] }, { id: "yacht", name: "Yacht Rock", genre: "Yacht rock", kind: "pack", songIds: ["o1BqHjNafRk", "u_pt3khMRFs", "CFhFyvk0yS8", "FXG_I_tf_i4", "7xvvLT_jRZY", "DzXEos0xIQM", "ohDqjRGqpIU", "QAo_Ycocl1E", "BVXmy22EoLA", "6POZlJAZsok", "IHL-6cUtZj0", "32Oc2d_3yEk", "WOBHXxiZyZM", "Yxy1eF_w7sU", "cvg5mbM6FGs", "SdfW_2frXnE", "3bRN257PBIg", "exiyXAV-aVQ", "swJOIjjW69U", "ywL6tMQdG4c", "5fYUpVAb34I", "EI0Tt3UZ5jc", "6mj-p6rITBw", "Omnpu8mzX4c", "EIMk9F7E0uM", "9QYk1E8zdxU", "gtlqZOT2fOo", "NoPH9LvVkDU", "1j_YC8OpSr4", "ky6vvIESPiM", "Ueivjr3f8xg", "Rq-7NgH-hcs", "OaOQdWyN67U", "XOuFO8KPnjw", "nCEuT91UAcg", "jEILGYq7eso", "Fa25MqOzGwk", "IL_LiGCV82g", "r8xZSwHirLg", "pFCi5usCbz4", "QCgeitX5xg0", "WH5WVmaZFNE", "Ot3JJ0wv2G0", "QQD-OvbCfCU", "8vpgoNDi71Q", "pCRoAKdKPVA", "oFXIHZ2mzIU", "v4XKRHyu3C8", "k1uA_Zw7zAk", "op9ApJJyhD4", "S3ta4T9tIUM", "TGkUdLJCLyE", "wzCdSJu5xqI", "tNtOYomo4Qg", "lHLr5dT4XHc", "3e8xSISlPJs", "XKc7z-enzmA", "6tynWSAesAo", "9KNuZrEVB70", "Kj4-_-iq1A8", "M-Z3BAW7o3c", "xftwDQ2PhvA", "kR5Ki6jjPaY", "GRQl9k71EBg", "Gby-B2xsuuQ", "muQqts3-g1w", "Yoithw8ysjo", "L0qBulm0hbg", "uu3QahP4uig", "0qycxTpMb5U", "qrU1Zg0wugE", "k5gOehkLUTk", "0VplLt39yrk", "McZYYe0kAtg", "O6abLniPBFU", "iM5Rd6oM-C4", "nuko5fhd4mA", "lnc2ljZA3bk", "yi4hbVAfRCw", "MG0e8_foDmU", "m0tmkm9KIAo", "1AVxBedMP4I", "ySy1y10JIpM", "ciLNMesqPh0", "7Ki7f4g9X9g", "lPkEpfwJX_Q", "irl89Gmcv8c", "XFnkJGoaDUs", "f1De87ETXwo", "n2orykBfo5o", "EZ-nCesR-oY", "zxFxl5NjBzc", "8cqhZ47Hg7g", "D4ZrKfrshP4"] }], B = "vh.song.", S = "vh.setlist.";
function z(e) {
  return String(e || "").replace(/^\(\d+\)\s*/, "").replace(/\s*[[(](?:official\s+)?(?:music\s+)?(?:video|audio|lyrics?|visuali[sz]er)(?:\s+(?:hd|4k))?[\])]/gi, "").replace(/\s*[-–]\s*official\s+(?:music\s+)?(?:video|audio)\s*$/i, "").trim();
}
function F(e) {
  const n = Object.entries(e).filter(([i, s]) => i.startsWith("vh.chart.") && /^[\w-]{11}$/.test(s?.youtubeId || "") && Array.isArray(s.notes)).map(([, i]) => i), r = Object.entries(e).filter(([i, s]) => i.startsWith("vh.score.") && s?.videoId).map(([, i]) => i), a = Object.entries(e).filter(([i, s]) => i.startsWith(S) && s?.id && Array.isArray(s.songIds)).map(([, i]) => i), o = [...J.filter((i) => !e[S + i.id]?.deleted && n.some((s) => i.songIds.includes(s.youtubeId))).map((i) => ({ ...i, ...e[S + i.id] })), ...a.filter((i) => !i.deleted && !J.some((s) => s.id === i.id))], c = n.map((i) => {
    const s = i.youtubeId, d = e[B + s] || {}, l = o.filter((g) => g.kind === "pack" && g.songIds.includes(s));
    return {
      id: s,
      chart: i,
      title: d.title || z(i.title) || s,
      genre: d.genre ?? l[0]?.genre ?? o.find((g) => g.songIds.includes(s) && g.genre)?.genre ?? "",
      packs: l,
      scores: r.filter((g) => g.videoId === s).sort((g, h) => String(h.date).localeCompare(String(g.date)))
    };
  });
  for (const i of r) if (!c.some((s) => s.id === i.videoId)) {
    const s = i.videoId, d = e[B + s] || {};
    c.push({ id: s, chart: null, title: d.title || z(i.title) || s, genre: d.genre || "", packs: [], scores: r.filter((l) => l.videoId === s).sort((l, g) => String(g.date).localeCompare(String(l.date))) });
  }
  return { songs: c, sets: o };
}
function H(e, n, { collection: r = "all", query: a = "", genre: o = "", sort: c = "recent" } = {}) {
  const i = n.find((l) => l.id === r), s = a.toLowerCase().trim();
  return e.filter((l) => (r === "all" || r === "manual" && !l.packs.length || i?.songIds.includes(l.id)) && (!o || l.genre === o) && (!s || `${l.title} ${l.genre} ${l.id}`.toLowerCase().includes(s))).sort((l, g) => c === "title" ? l.title.localeCompare(g.title) : c === "genre" ? l.genre.localeCompare(g.genre) || l.title.localeCompare(g.title) : c === "order" && i ? i.songIds.indexOf(l.id) - i.songIds.indexOf(g.id) : String(g.chart?.savedAt || "").localeCompare(String(l.chart?.savedAt || "")));
}
function R(e, n) {
  return { ...e, songIds: [.../* @__PURE__ */ new Set([...e.songIds, ...n])] };
}
function T(e, n, r) {
  const a = e.songIds.filter((c) => c !== n), o = a.indexOf(r);
  return a.splice(o < 0 ? a.length : o, 0, n), { ...e, songIds: a };
}
const Q = (e) => e ? JSON.stringify([e.videoId, e.status, e.updatedAt, e.title, e.error]) : "";
function re(e, n, r = !1) {
  const { sets: a } = F(e), o = a.find((s) => s.id === n);
  if (!o) throw Error("This setlist no longer exists.");
  const c = { [S + n]: { id: n, deleted: !0, songIds: [] } }, i = [];
  if (r) {
    const s = new Set(o.songIds);
    for (const [d, l] of Object.entries(e))
      (d.startsWith("vh.chart.") && s.has(l?.youtubeId) || d.startsWith(B) && s.has(d.slice(B.length)) || d.startsWith("vh.score.") && s.has(l?.videoId)) && i.push(d);
    for (const d of a) d.id !== n && d.songIds.some((l) => s.has(l)) && (c[S + d.id] = { ...d, songIds: d.songIds.filter((l) => !s.has(l)) });
  }
  return { updates: c, remove: i };
}
const t = (e) => document.getElementById(e), y = chrome.storage.local;
let j = {}, u = { songs: [], sets: [] }, E = "all", k = 0, m = /* @__PURE__ */ new Set(), U = null, $ = [], O = null, x = null, I = !1, G = 0;
const M = 20;
function p(e, n, r) {
  const a = document.createElement(e);
  return n !== void 0 && (a.textContent = n), r && (a.className = r), a;
}
function P(e, n) {
  const r = p("button", e);
  return r.type = "button", r.onclick = () => b(n), r;
}
function v(e) {
  t("message").textContent = e;
}
async function b(e) {
  try {
    await e();
  } catch (n) {
    v(`Could not save changes: ${n.message}`);
  }
}
function q(e, n) {
  const r = URL.createObjectURL(new Blob([JSON.stringify(e)], { type: "application/json" })), a = p("a");
  a.href = r, a.download = n, document.body.append(a), a.click(), a.remove(), setTimeout(() => URL.revokeObjectURL(r), 1e3);
}
function N() {
  return u.sets.find((e) => e.id === E);
}
async function A(e) {
  await y.set({ [S + e.id]: e }), await L();
}
async function L() {
  if (I) return;
  const e = ++G;
  try {
    const n = await y.get(null);
    if (e !== G) return;
    j = n, u = F(j), C();
  } catch (n) {
    v(`Could not load your library: ${n.message}`);
  }
}
function W(e) {
  E = e, k = 0, m.clear(), C();
}
function C() {
  const e = t("collections");
  e.replaceChildren();
  function n(s, d, l, g) {
    const h = P("", () => W(s));
    h.append(p("span", d), p("small", String(l))), h.setAttribute("aria-current", s === E ? "page" : "false"), g && (h.ondragover = (f) => {
      f.preventDefault(), h.classList.add("drop-target");
    }, h.ondragleave = () => h.classList.remove("drop-target"), h.ondrop = (f) => {
      f.preventDefault(), h.classList.remove("drop-target");
      const w = f.dataTransfer.getData("text/plain");
      u.songs.some((D) => D.id === w) && b(async () => {
        await A(R(g, [w])), v(`Added song to ${g.name}.`);
      });
    }), e.append(h);
  }
  n("all", "All songs", u.songs.length), n("manual", "Manual additions", u.songs.filter((s) => !s.packs.length).length);
  for (const s of ["pack", "custom"]) {
    e.append(p("h2", s === "pack" ? "Song packs" : "Your setlists"));
    for (const d of u.sets.filter((l) => (l.kind === "pack" ? "pack" : "custom") === s)) n(d.id, d.name, u.songs.filter((l) => d.songIds.includes(l.id)).length, d);
  }
  const r = [...new Set(u.songs.map((s) => s.genre).filter(Boolean))].sort(), a = t("genre").value;
  t("genre").replaceChildren(new Option("All genres", ""), ...r.map((s) => new Option(s, s))), t("genre").value = r.includes(a) ? a : "", t("genres").replaceChildren(...r.map((s) => new Option(s, s)));
  const o = t("target-set").value;
  t("target-set").replaceChildren(new Option("Choose a setlist", ""), ...u.sets.map((s) => new Option(s.name, s.id))), t("target-set").value = o;
  const c = N();
  t("collection-title").textContent = c?.name || (E === "manual" ? "Manual additions" : "All songs"), t("rename-set").hidden = !c, t("delete-set").hidden = !c, t("remove-selected").hidden = !c;
  const i = H(u.songs, u.sets, { collection: E, query: t("search").value, genre: t("genre").value, sort: t("sort").value });
  k = Math.max(0, Math.min(k, Math.ceil(i.length / M) - 1)), $ = i.slice(k * M, (k + 1) * M), t("count").textContent = `${i.length} songs${c?.genre ? " · " + c.genre : ""}`, t("songs").replaceChildren(), $.length || t("songs").append(p("p", u.songs.length ? "No songs match. Try another collection or clear your filters." : "Import your first song pack, or prepare a song from the extension popup.", "empty"));
  for (const s of $) {
    const d = p("article", void 0, "song-row");
    d.draggable = !0, d.ondragstart = (f) => f.dataTransfer.setData("text/plain", s.id), d.ondragover = (f) => {
      c && t("sort").value === "order" && (f.preventDefault(), d.classList.add("drop-target"));
    }, d.ondragleave = () => d.classList.remove("drop-target"), d.ondrop = (f) => {
      f.preventDefault(), d.classList.remove("drop-target");
      const w = f.dataTransfer.getData("text/plain");
      c && t("sort").value === "order" && c.songIds.includes(w) && w !== s.id && b(() => A(T(c, w, s.id)));
    };
    const l = p("input");
    l.type = "checkbox", l.checked = m.has(s.id), l.setAttribute("aria-label", `Select ${s.title}`), l.onchange = () => {
      l.checked ? m.add(s.id) : m.delete(s.id), K();
    };
    const g = P("", () => _(s.id));
    g.className = "song-info", g.append(p("strong", s.title), p("small", `${s.genre || "No genre"} · ${s.chart ? Math.round(s.chart.settings?.bpm || 120) + " BPM" : "Chart not installed"} · ${s.scores.length} saved scores`));
    const h = p("a", "Play ↗", "play-link");
    if (h.href = `https://www.youtube.com/watch?v=${s.id}`, h.target = "_blank", h.rel = "noreferrer", h.setAttribute("aria-label", `Open ${s.title} on YouTube`), d.append(l, g, h), c && t("sort").value === "order") {
      const f = c.songIds.indexOf(s.id), w = P("↑", () => A(T(c, s.id, c.songIds[f - 1])));
      w.disabled = f <= 0, w.setAttribute("aria-label", `Move ${s.title} up`);
      const D = P("↓", () => A(T(c, s.id, c.songIds[f + 2])));
      D.disabled = f >= c.songIds.length - 1, D.setAttribute("aria-label", `Move ${s.title} down`), d.append(w, D);
    }
    t("songs").append(d);
  }
  t("page-label").textContent = i.length ? `${k * M + 1}–${Math.min((k + 1) * M, i.length)} of ${i.length}` : "0 songs", t("previous").disabled = k === 0, t("next").disabled = (k + 1) * M >= i.length, K(), V();
}
function K() {
  t("selected-count").textContent = `${m.size} selected`, t("select-page").checked = $.length > 0 && $.every((e) => m.has(e.id)), t("select-page").indeterminate = $.some((e) => m.has(e.id)) && !t("select-page").checked;
  for (const e of ["add-selected", "remove-selected", "clear-selected"]) t(e).disabled = !m.size;
}
function V() {
  const e = j["vh.preparation"];
  if (t("preparation").hidden = !e || j["vh.dismissedPreparation"] === Q(e), !e) return;
  const n = e.status === "preparing", r = n && Date.now() - e.updatedAt > 15e3;
  t("status").textContent = `${e.title || e.videoId}: ${r ? "No recent progress. Check the song tab or cancel preparation." : e.status === "ready" ? "Saved and ready to play." : n ? `Preparing quietly · ${Math.round(e.progress || 0)}%` : e.error || e.status}`, t("progress").hidden = !n, t("progress").value = e.progress || 0, t("cancel").hidden = !n, t("dismiss").hidden = n;
}
function _(e) {
  U = e;
  const n = u.songs.find((r) => r.id === e);
  if (n) {
    t("song-panel").hidden = !1, t("detail-title").textContent = n.title, t("edit-title").value = n.title, t("edit-genre").value = n.genre, t("detail-play").href = `https://www.youtube.com/watch?v=${e}`, t("backup-song").disabled = !n.chart, t("memberships").replaceChildren();
    for (const r of u.sets) {
      const a = p("label", void 0, "membership"), o = p("input");
      o.type = "checkbox", o.checked = r.songIds.includes(e), o.onchange = () => b(async () => {
        const c = F(await y.get(null)).sets.find((i) => i.id === r.id);
        await A(o.checked ? R(c, [e]) : { ...c, songIds: c.songIds.filter((i) => i !== e) });
      }), a.append(o, document.createTextNode(r.name)), t("memberships").append(a);
    }
    t("song-scores").replaceChildren(), n.scores.length || t("song-scores").append(p("p", "No saved scores yet. Finish a run and save your result.", "hint"));
    for (const r of n.scores) {
      const a = p("article", void 0, "score-entry");
      a.append(p("strong", `${r.username || "Player"} · ${Number(r.score || 0).toLocaleString()} pts`), p("p", `${r.difficulty} · ${r.chords ? "Chords" : "Single notes"} · ${r.accuracy}% hit · Best streak ${r.best}`), p("small", `${r.outcome === "failed" ? "Failed attempt · " : r.competitiveEligible === !1 ? "Practice · " : ""}${new Date(r.date).toLocaleString()}`), P("Export score", () => q(r, `vibe-hero-score-${r.id}.json`))), t("song-scores").append(a);
    }
  }
}
t("close-panel").onclick = () => {
  t("song-panel").hidden = !0, U = null;
};
t("edit-song").onsubmit = (e) => {
  e.preventDefault(), b(async () => {
    const n = t("edit-title").value.trim();
    if (!n) throw Error("Enter a song title.");
    const r = B + U, a = (await y.get(r))[r] || {};
    await y.set({ [r]: { ...a, title: n, genre: t("edit-genre").value.trim() } }), await L(), _(U), v("Song details saved.");
  });
};
t("backup-song").onclick = () => {
  const e = u.songs.find((n) => n.id === U);
  e?.chart && q({ ...e.chart, title: e.title }, `vibe-hero-${U}.json`);
};
t("new-set").onsubmit = (e) => {
  e.preventDefault(), b(async () => {
    const n = t("set-name").value.trim();
    if (!n) return;
    const r = { id: crypto.randomUUID(), name: n, kind: "custom", genre: "", songIds: [] };
    await A(r), t("set-name").value = "", W(r.id), v("Setlist created. Drag songs here or use Add to setlist.");
  });
};
t("search").oninput = () => {
  k = 0, C();
};
t("genre").onchange = t("sort").onchange = () => {
  k = 0, C();
};
t("previous").onclick = () => {
  k--, C();
};
t("next").onclick = () => {
  k++, C();
};
t("select-page").onchange = (e) => {
  for (const n of $) e.target.checked ? m.add(n.id) : m.delete(n.id);
  C();
};
t("clear-selected").onclick = () => {
  m.clear(), C();
};
t("add-selected").onclick = () => b(async () => {
  const e = u.sets.find((n) => n.id === t("target-set").value);
  if (!e) throw Error("Choose a destination setlist.");
  await A(R(e, [...m])), v(`Added ${m.size} songs to ${e.name}.`);
});
t("remove-selected").onclick = () => b(async () => {
  const e = N();
  e && (await A({ ...e, songIds: e.songIds.filter((n) => !m.has(n)) }), m.clear(), C(), v("Removed from this setlist. Songs and scores remain in All songs."));
});
t("export-set").onclick = () => {
  const e = N(), n = H(u.songs, u.sets, { collection: E, sort: "order" }), r = n.filter((a) => a.chart).map((a) => ({ ...a.chart, title: a.title, genre: a.genre }));
  if (!r.length) {
    v("This collection has no installed charts to export.");
    return;
  }
  q({ version: 1, name: e?.name || t("collection-title").textContent, genre: e?.genre || "", charts: r }, "vibe-hero-setlist.json");
};
t("cancel").onclick = () => b(async () => {
  const e = await chrome.runtime.sendMessage({ target: "background", type: "cancel" });
  if (e?.error) throw Error(e.error);
  v("Cancellation requested.");
});
t("dismiss").onclick = () => b(async () => {
  const e = (await y.get("vh.preparation"))["vh.preparation"];
  if (e?.status === "preparing") throw Error("Preparation is active. Cancel it before dismissing.");
  await y.set({ "vh.dismissedPreparation": Q(e) }), await L();
});
t("import-pack").onchange = async (e) => {
  const n = e.target.files?.[0];
  if (e.target.value = "", !!n)
    try {
      if (n.size > 30 * 1024 * 1024) throw Error("Choose a pack smaller than 30 MB.");
      O = JSON.parse(await n.text());
      const r = Z(O);
      x = null, t("pack-heading").textContent = "Import a song pack", t("pack-description").textContent = `${r.length} charts. Existing charts for the same recordings will be replaced; your titles, setlists and scores are preserved.`, t("pack-name").value = O.name || n.name.replace(/\.json$/i, "").replace(/^Vibe Hero\s*[-–]?\s*/i, ""), t("pack-genre").value = O.genre || (/yacht/i.test(n.name) ? "Yacht rock" : /indie/i.test(n.name) ? "Indie rock" : ""), t("save-pack").textContent = "Import pack", t("pack-error").textContent = "", t("pack-dialog").showModal();
    } catch (r) {
      v(r.message);
    }
};
t("rename-set").onclick = () => {
  x = N(), O = null, t("pack-heading").textContent = "Edit setlist", t("pack-description").textContent = "The genre applies to songs without their own genre override.", t("pack-name").value = x.name, t("pack-genre").value = x.genre || "", t("save-pack").textContent = "Save setlist", t("pack-error").textContent = "", t("pack-dialog").showModal();
};
t("cancel-pack").onclick = () => t("pack-dialog").close();
t("pack-form").onsubmit = async (e) => {
  e.preventDefault();
  const n = t("pack-name").value.trim(), r = t("pack-genre").value.trim();
  if (n) {
    I = !0, t("save-pack").disabled = !0, t("cancel-pack").disabled = !0;
    try {
      if (x) await y.set({ [S + x.id]: { ...x, name: n, genre: r } });
      else {
        const a = Z(O);
        await se(O, y);
        const o = a.map((s) => s.youtubeId), i = u.sets.find((s) => s.kind === "pack" && s.songIds.length === o.length && o.every((d) => s.songIds.includes(d)))?.id || crypto.randomUUID();
        await y.set({ [S + i]: { id: i, name: n, genre: r, kind: "pack", songIds: o } }), E = i, k = 0;
      }
      t("pack-dialog").close(), v(x ? "Setlist updated." : "Song pack imported into your library.");
    } catch (a) {
      t("pack-error").textContent = a.message;
    } finally {
      I = !1, t("save-pack").disabled = !1, t("cancel-pack").disabled = !1, await L();
    }
  }
};
t("pack-dialog").addEventListener("cancel", (e) => {
  I && e.preventDefault();
});
chrome.storage.onChanged.addListener(() => L());
L();
setInterval(() => {
  I || V();
}, 5e3);
let Y = null;
t("delete-set").onclick = () => {
  Y = N()?.id, Y && (t("delete-description").textContent = `Remove “${N().name}”? By default, its songs and scores stay in All songs.`, t("delete-songs").checked = !1, t("delete-error").textContent = "", t("delete-dialog").showModal());
};
t("cancel-delete").onclick = () => t("delete-dialog").close();
t("delete-dialog").addEventListener("cancel", (e) => {
  I && e.preventDefault();
});
t("delete-form").onsubmit = async (e) => {
  if (e.preventDefault(), !I) {
    I = !0, t("confirm-delete").disabled = !0, t("cancel-delete").disabled = !0;
    try {
      const n = re(await y.get(null), Y, t("delete-songs").checked);
      await y.set(n.updates), n.remove.length && await y.remove(n.remove), E = "all", k = 0, m.clear(), U = null, t("song-panel").hidden = !0, t("delete-dialog").close(), v("Setlist deleted.");
    } catch (n) {
      t("delete-error").textContent = n.message;
    } finally {
      I = !1, t("confirm-delete").disabled = !1, t("cancel-delete").disabled = !1, await L();
    }
  }
};
