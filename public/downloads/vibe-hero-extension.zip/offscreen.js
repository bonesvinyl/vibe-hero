class K {
  constructor(t, n) {
    if (this.context = t, this.source = n, this.input = t.createGain(), this.delay = t.createDelay(1), this.feedback = t.createGain(), this.filter = t.createBiquadFilter(), this.output = t.createGain(), this.input.gain.value = 0, this.output.gain.value = 0, this.delay.delayTime.value = 0.19, this.feedback.gain.value = 0.38, this.filter.type = "lowpass", this.filter.frequency.value = 3200, n.connect(this.input), this.input.connect(this.delay), this.delay.connect(this.filter), this.filter.connect(this.feedback), this.feedback.connect(this.delay), this.filter.connect(this.output), this.output.connect(t.destination), this.reverbNodes = [], t.createConvolver && t.createBuffer) {
      const o = t.createConvolver(), r = t.createGain(), s = t.createBuffer(2, Math.ceil(t.sampleRate * 2.6), t.sampleRate);
      let m = 71;
      for (let a = 0; a < 2; a++) {
        const u = s.getChannelData(a);
        for (let f = 0; f < u.length; f++)
          m = m * 16807 % 2147483647, u[f] = (m / 10737418235e-1 - 1) * Math.pow(1 - f / u.length, 2.4);
      }
      o.buffer = s, r.gain.value = 0.65, this.input.connect(o), o.connect(r), r.connect(this.output), this.reverbNodes = [o, r];
    }
    this.active = !1;
  }
  set(t) {
    if (this.active !== t) {
      this.active = t;
      for (const [n, o] of [[this.input.gain, t ? 1 : 0], [this.output.gain, t ? 0.42 : 0]])
        n.cancelScheduledValues(this.context.currentTime), n.setTargetAtTime(o, this.context.currentTime, t ? 0.08 : 0.025);
    }
  }
  destroy() {
    this.source.disconnect(this.input);
    for (const t of [this.input, this.delay, this.feedback, this.filter, this.output, ...this.reverbNodes]) t.disconnect();
  }
}
function R(e, t) {
  if (e.length < t * 3) return { bpm: null, confidence: 0 };
  const n = [0];
  for (const a of e) n.push(n.at(-1) + a);
  const o = e.map((a, u) => {
    const f = Math.max(0, u - 20), i = Math.min(e.length, u + 21);
    return Math.max(0, a - (n[i] - n[f]) / (i - f));
  });
  if (o.filter((a) => a > 1e-3).length < 4)
    return { bpm: null, confidence: 0 };
  const r = [];
  for (let a = 60; a <= 200; a += 0.5) {
    const u = 60 * t / a, f = Math.floor(u), i = u - f;
    let h = 0, p = 0, b = 0;
    for (let d = f + 1; d < o.length; d++) {
      const w = o[d], c = o[d - f] * (1 - i) + o[d - f - 1] * i;
      h += w * c, p += w * w, b += c * c;
    }
    const g = h / Math.sqrt(p * b || 1);
    r.push({
      bpm: a,
      score: g,
      rank: g * (1 - 0.025 * Math.abs(Math.log2(a / 120)))
    });
  }
  r.sort((a, u) => u.rank - a.rank);
  let s = r[0];
  const m = r.filter((a) => {
    const u = a.bpm / s.bpm;
    return u >= 1.9 && u <= 3.1 && Math.abs(u - Math.round(u)) < 0.015 && a.score >= s.score * 0.85;
  });
  return m.length && (s = m.sort((a, u) => u.bpm - a.bpm)[0]), s.score < 0.18 ? { bpm: null, confidence: s.score } : { bpm: s.bpm, confidence: Math.min(1, s.score) };
}
function U(e, t = "medium") {
  if (e.length < 3) return { notes: [], bpm: null, confidence: 0 };
  let n = 0, o = 0;
  for (const i of e)
    n = Math.max(n, i.flux), o = Math.max(o, i.energy);
  if (n < 1e-3) return { notes: [], bpm: null, confidence: 0 };
  const r = [], s = { easy: 0.36, medium: 0.2, hard: 0.12, expert: 0.09 }[t] || 0.2;
  for (let i = 2; i < e.length - 2; i++) {
    const h = e[i], p = e.slice(Math.max(0, i - 15), i + 16), b = Math.max(n * 0.035, p.reduce((w, c) => w + c.flux, 0) / p.length * 1.45);
    if (h.energy < o * 8e-3 || h.flux <= b || h.flux < e[i - 1].flux || h.flux <= e[i + 1].flux) continue;
    const g = r.at(-1), d = { ...h, index: i };
    !g || h.time - g.time >= s ? r.push(d) : h.flux > g.flux && (r[r.length - 1] = d);
  }
  const m = r.map((i) => i.tone).sort((i, h) => i - h), a = [0.2, 0.4, 0.6, 0.8].map((i) => m[Math.floor(i * (m.length - 1))]), u = r.map((i, h) => {
    const p = a.filter((c) => i.tone > c).length, b = ["hard", "expert"].includes(t) && i.flux > n * 0.8 ? [0, 2, 4] : t !== "easy" && i.flux > n * 0.55 ? [p, (p + 2) % 5].sort() : [p], g = Math.min(r[h + 1]?.time - 0.07 || 1 / 0, i.time + 6);
    let d = i.time;
    for (let c = i.index + 1; c < e.length && e[c].time < g && !(e[c].energy < Math.max(o * 8e-3, i.energy * 0.3)); c++)
      d = e[c].time;
    const w = d - i.time;
    return { time: Math.max(0, i.time), lanes: b, ...w >= 0.4 ? { duration: +w.toFixed(4) } : {} };
  }), f = Array(Math.ceil(e.at(-1).time * 50) + 1).fill(0);
  for (const i of e) {
    const h = Math.round(i.time * 50);
    f[h] = Math.max(f[h] || 0, i.flux);
  }
  return { notes: u, ...R(f, 50) };
}
function $(e, t) {
  if (!Array.isArray(e.notes) || !e.notes.length || e.notes.length > 2e4)
    throw new Error("Expected a version 1 chart with 1–20,000 notes.");
  let n = -1;
  const o = Array(5).fill(-1);
  return e.notes.map((r) => {
    if (!Number.isFinite(r.time) || r.time < 0 || r.time >= t || r.time - n < 0.04)
      throw new Error(
        "Chart times must increase, be at least 40 ms apart, and fit this track."
      );
    if (!Array.isArray(r.lanes) || !r.lanes.length || r.lanes.length > 5 || new Set(r.lanes).size !== r.lanes.length || r.lanes.some((s) => !Number.isInteger(s) || s < 0 || s > 4))
      throw new Error("Each note needs unique lanes from 0 through 4.");
    if (r.duration !== void 0 && (!Number.isFinite(r.duration) || r.duration < 0 || r.time + r.duration > t))
      throw new Error("Hold duration must be nonnegative and fit this track.");
    if (r.lanes.some((s) => o[s] > r.time)) throw new Error("A fret cannot overlap its previous hold.");
    for (const s of r.lanes) o[s] = r.time + (r.duration || 0);
    return n = r.time, { time: r.time, lanes: [...r.lanes].sort(), ...r.duration > 0 ? { duration: r.duration } : {} };
  });
}
function H(e = {}) {
  const t = (n, o, r, s) => Number.isFinite(e?.[n]) && e[n] >= r && e[n] <= s ? e[n] : o;
  return { triples: e?.triples !== !1, chords: e?.chords !== !1, bpm: t("bpm", 120, 40, 240), firstBeat: t("firstBeat", 2.5, 0, 120), offset: t("offset", 0, -500, 500), difficulty: ["easy", "medium", "hard", "expert"].includes(e?.difficulty) ? e.difficulty : "medium", mode: e?.mode === "strum" ? "strum" : "tap" };
}
const J = (e) => {
  if (!/^[\w-]{11}$/.test(e)) throw new Error("Invalid recording ID.");
  return `vh.chart.${e}`;
};
async function V(e, t, n, o, r, s) {
  const m = J(t);
  if (!Number.isFinite(o) || o < 3 || o > 1200) throw new Error("The song duration is unavailable. Try saving after the song loads.");
  const a = { version: 1, youtubeId: t, notes: $(n, o), duration: o, settings: H(r), title: String(s || "").slice(0, 300), savedAt: (/* @__PURE__ */ new Date()).toISOString() };
  if (JSON.stringify(a).length > 2 * 1024 * 1024) throw new Error("This chart is too large to save.");
  return await e.set({ [m]: a }), a;
}
function W(e, t, n) {
  return !e || n - t > 350 || e.ad || e.paused || e.seeking || e.ready < 3 || e.rate !== 1 ? null : Math.min(e.duration, e.time + Math.max(0, n - t) / 1e3);
}
function _(e, t) {
  return e.length > 0 && e.at(-1).time >= t - 0.25;
}
let M = null, v = null;
async function F() {
  const e = v;
  v = null, e && (clearInterval(e.timer), e.echo?.destroy(), e.source?.disconnect(), e.stream?.getTracks().forEach((t) => t.stop()), await e.context?.close());
}
async function Q(e) {
  if (M || v) throw new Error("Finish the current preparation or game first.");
  const t = { tabId: e.tabId, lastSeen: Date.now() };
  v = t;
  try {
    return t.stream = await navigator.mediaDevices.getUserMedia({ audio: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: e.streamId } }, video: !1 }), t.context = new AudioContext(), await t.context.resume(), t.source = t.context.createMediaStreamSource(t.stream), t.source.connect(t.context.destination), t.echo = new K(t.context, t.source), t.timer = setInterval(() => {
      Date.now() - t.lastSeen > 6e3 && F();
    }, 1e3), t.stream.getTracks().forEach((n) => {
      n.onended = () => F();
    }), { ok: !0 };
  } catch (n) {
    throw await F(), n;
  }
}
const P = async (e, t = "state") => {
  let n;
  const o = await Promise.race([
    chrome.runtime.sendMessage({ target: "background", type: "player", tabId: e.tabId, videoId: e.videoId, action: t }),
    new Promise((r, s) => {
      n = setTimeout(() => s(new Error("The song tab stopped responding.")), 4e3);
    })
  ]).finally(() => clearTimeout(n));
  if (o?.error || !o) throw new Error(o?.error || "Player is unavailable.");
  return o;
}, O = { async set(e) {
  const t = await chrome.runtime.sendMessage({ target: "background", type: "storage-set", value: e });
  if (t?.error || !t?.ok) throw new Error(t?.error || "Could not save to the library.");
} }, D = (e) => O.set({ "vh.preparation": e });
chrome.runtime.onMessage.addListener((e, t, n) => {
  if (t.id !== chrome.runtime.id || e.target !== "offscreen") return;
  if (t.tab)
    return v?.tabId !== t.tab.id ? void 0 : (e.type === "effect-state" && (v.lastSeen = Date.now(), v.echo?.set(e.active === !0), n({ ok: !0 })), e.type === "effect-close" ? (F().then(() => n({ ok: !0 })), !0) : void 0);
  if (e.type === "start-effects")
    return Q(e).then(n).catch((r) => n({ error: r.message })), !0;
  if (e.type === "status") {
    n({ busy: !!M || !!v });
    return;
  }
  if (e.type === "cancel") {
    M?.controller.abort(), n({ ok: !0 });
    return;
  }
  if (e.type !== "start") return;
  if (M || v) {
    n({ error: "Another song is already preparing." });
    return;
  }
  M = { ...e, beganAt: Date.now(), controller: new AbortController() };
  const o = M;
  X(o).finally(() => {
    M === o && (M = null);
  }), n({ ok: !0 });
});
async function X(e) {
  let t, n, o, r, s = !1, m, a = 0, u = 0, f = 0, i, h = 0, p = !1, b = Promise.resolve();
  const g = [], d = e.controller.signal, w = () => t?.getTracks().forEach((c) => c.stop());
  try {
    if (await D({ videoId: e.videoId, title: e.title, status: "preparing", progress: 0, updatedAt: Date.now() }), t = await navigator.mediaDevices.getUserMedia({ audio: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: e.streamId } }, video: !1 }), d.aborted) throw new DOMException("Cancelled", "AbortError");
    n = new AudioContext(), await n.resume(), o = n.createMediaStreamSource(t);
    const c = n.createAnalyser();
    c.fftSize = 2048, c.smoothingTimeConstant = 0, o.connect(c);
    const x = new Float32Array(c.frequencyBinCount), C = new Float32Array(c.fftSize);
    if (d.aborted) throw new DOMException("Cancelled", "AbortError");
    m = await P(e, "start"), a = performance.now(), await new Promise((G, j) => {
      let k = !1;
      const S = () => E(new DOMException("Cancelled", "AbortError")), E = (y) => {
        k || (k = !0, clearInterval(r), d.removeEventListener("abort", S), y ? j(y) : G());
      };
      if (d.addEventListener("abort", S, { once: !0 }), d.aborted) {
        S();
        return;
      }
      r = setInterval(() => {
        const y = performance.now();
        if (_(g, e.duration)) {
          E();
          return;
        }
        if (d.aborted) {
          S();
          return;
        }
        if (Date.now() - e.beganAt > 2700 * 1e3) {
          E(new Error("Preparation timed out."));
          return;
        }
        if (t.getTracks().some((l) => l.readyState === "ended")) {
          E(new Error("Capture stopped before the chart was complete."));
          return;
        }
        if (y - a > 3e3) {
          E(new Error("Lost contact with the song tab. Keep it open while preparing."));
          return;
        }
        !s && y - u >= 100 && (s = !0, u = y, P(e).then((l) => {
          if (!k) {
            if (l.ad)
              p = !0, i = null;
            else if (p)
              h = l.time, p = !1, i = null;
            else if (!l.seeking && (l.time < m.time - 0.25 || l.time > m.time + (performance.now() - a) / 1e3 + 0.75)) throw new Error("The song was skipped. Prepare again without seeking.");
            if (!l.ad && l.rate !== 1) throw new Error("Keep playback at normal speed while preparing.");
            m = l, a = performance.now();
          }
        }).catch((l) => E(l)).finally(() => {
          s = !1;
        }));
        const I = W(m, a, y);
        if (I === null || I <= h) return;
        c.getFloatFrequencyData(x), c.getFloatTimeDomainData(C);
        let T = 0, q = 0, B = 0;
        const N = new Float32Array(x.length);
        for (const l of C) B += l * l;
        for (let l = 0; l < x.length; l++) {
          N[l] = Math.pow(10, x[l] / 20);
          const z = l * n.sampleRate / c.fftSize;
          if (!i || z < 80 || z > 5e3) continue;
          const L = Math.max(0, N[l] - i[l]);
          T += L, q += L * l;
        }
        i && g.push({ time: I, flux: T, tone: T ? q / T : 0, energy: Math.sqrt(B / C.length) }), i = N, h = I, y - f > 1e3 && (f = y, b = D({ videoId: e.videoId, title: e.title, status: "preparing", progress: Math.min(99, Math.round(I / e.duration * 100)), updatedAt: Date.now() }).catch((l) => E(l)));
      }, 20);
    }), await b;
    const A = U(g, e.difficulty);
    if (!A.notes.length) throw new Error("No clear audio attacks were captured. No chart was saved.");
    await V(O, e.videoId, { version: 1, notes: A.notes }, e.duration, { bpm: A.bpm || 120, difficulty: e.difficulty }, e.title), await D({ videoId: e.videoId, title: e.title, status: "ready", progress: 100, notes: A.notes.length, updatedAt: Date.now() });
  } catch (c) {
    await b.catch(() => {
    }), await D({ videoId: e.videoId, title: e.title, status: d.aborted ? "cancelled" : "error", error: c.message, updatedAt: Date.now() }).catch(() => {
    });
  } finally {
    clearInterval(r), d.removeEventListener("abort", w), await P(e, "stop").catch(() => {
    }), w(), o?.disconnect(), await n?.close();
  }
}
